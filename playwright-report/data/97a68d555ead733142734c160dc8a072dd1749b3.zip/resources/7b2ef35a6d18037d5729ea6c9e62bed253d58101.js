(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/next-theme/theme-provider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$themes$40$0$2e$4$2e$6_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next-themes@0.4.6_react-dom@19.2.3_react@19.2.3__react@19.2.3/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
function ThemeProvider(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "a76c19da875744f0d25585c4191790640e0e65088e8e3bd199fc63302aeb5f38") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a76c19da875744f0d25585c4191790640e0e65088e8e3bd199fc63302aeb5f38";
    }
    let children;
    let props;
    if ($[1] !== t0) {
        ({ children, ...props } = t0);
        $[1] = t0;
        $[2] = children;
        $[3] = props;
    } else {
        children = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== children || $[5] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$themes$40$0$2e$4$2e$6_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3$2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
            ...props,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/next-theme/theme-provider.tsx",
            lineNumber: 30,
            columnNumber: 10
        }, this);
        $[4] = children;
        $[5] = props;
        $[6] = t1;
    } else {
        t1 = $[6];
    }
    return t1;
}
_c = ThemeProvider;
var _c;
__turbopack_context__.k.register(_c, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_REDUCED_RATE_PERCENTAGE",
    ()=>DEFAULT_REDUCED_RATE_PERCENTAGE,
    "cn",
    ()=>cn,
    "decodeCsvContent",
    ()=>decodeCsvContent,
    "downloadCsv",
    ()=>downloadCsv,
    "generateCsv",
    ()=>generateCsv,
    "getEffectiveRecurringRate",
    ()=>getEffectiveRecurringRate,
    "getErrorMessage",
    ()=>getErrorMessage,
    "getRecurringRateDescription",
    ()=>getRecurringRateDescription,
    "getSanitizedErrorMessage",
    ()=>getSanitizedErrorMessage,
    "reportClientError",
    ()=>reportClientError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$5$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tailwind-merge@3.5.0/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$5$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
const DEFAULT_REDUCED_RATE_PERCENTAGE = 50;
function getEffectiveRecurringRate(commissionRate, recurringRateType, recurringRate) {
    if (!recurringRateType || recurringRateType === "same") {
        return commissionRate;
    }
    if (recurringRateType === "reduced") {
        return commissionRate * (DEFAULT_REDUCED_RATE_PERCENTAGE / 100);
    }
    // custom - use the provided recurring rate or fall back to commission rate
    return recurringRate ?? commissionRate;
}
function getRecurringRateDescription(recurringRateType, recurringRate, commissionRate) {
    if (!recurringRateType || recurringRateType === "same") {
        return `Same as initial (${commissionRate || 0}%)`;
    }
    if (recurringRateType === "reduced") {
        const reducedRate = (commissionRate || 0) * (DEFAULT_REDUCED_RATE_PERCENTAGE / 100);
        return `Reduced (${reducedRate.toFixed(1)}%)`;
    }
    // custom
    return `Custom (${recurringRate || 0}%)`;
}
function downloadCsv(base64Data, filename) {
    // Decode base64 to string
    const csvContent = atob(base64Data);
    // Create blob from CSV content
    const blob = new Blob([
        csvContent
    ], {
        type: "text/csv;charset=utf-8;"
    });
    // Create object URL
    const url = URL.createObjectURL(blob);
    // Create download link
    const link = document.createElement("a");
    const date = new Date().toISOString().split("T")[0];
    link.href = url;
    link.download = `${filename}-${date}.csv`;
    // Trigger download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    // Clean up
    URL.revokeObjectURL(url);
}
function decodeCsvContent(base64Data) {
    return atob(base64Data);
}
function generateCsv(rows) {
    if (rows.length === 0) return "";
    const headers = Object.keys(rows[0]);
    const escape = (val)=>{
        let str = String(val ?? "");
        // Sanitize formula-triggering characters to prevent CSV injection
        if (/^[=+\-@\t\r]/.test(str)) {
            str = "'" + str;
        }
        if (str.includes(",") || str.includes('"') || str.includes("\n")) {
            return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
    };
    const lines = [
        headers.map(escape).join(","),
        ...rows.map((row)=>headers.map((h)=>escape(row[h])).join(","))
    ];
    const csv = lines.join("\n");
    // Unicode-safe base64 encode for compatibility with downloadCsv
    const bytes = new TextEncoder().encode(csv);
    const binString = Array.from(bytes, (b)=>String.fromCharCode(b)).join("");
    return btoa(binString);
}
function getErrorMessage(error, fallback, depth = 0) {
    const MAX_DEPTH = 5;
    if (depth > MAX_DEPTH) return fallback;
    if (error == null) return fallback;
    if (typeof error === "string") return error;
    if (error instanceof Error) {
        const msg = error.message;
        if (msg && msg.length > 0) {
            return msg;
        }
        if (error.cause !== undefined) {
            return getErrorMessage(error.cause, fallback, depth + 1);
        }
        return fallback;
    }
    const err = error;
    if (typeof err.message === "string" && err.message.length > 0) {
        return err.message;
    }
    if (err.data && typeof err.data === "object") {
        const data = err.data;
        if (typeof data.message === "string" && data.message.length > 0) {
            return data.message;
        }
        if (data.cause !== undefined) {
            return getErrorMessage(data.cause, fallback, depth + 1);
        }
    }
    if (err.cause !== undefined) {
        return getErrorMessage(err.cause, fallback, depth + 1);
    }
    return fallback;
}
const CONVEX_INTERNAL_PREFIXES = [
    "ReturnsValidationError",
    "ArgumentValidationError",
    "FunctionError",
    "INVALID_ARGUMENT",
    "Cannot read properties of undefined",
    "Cannot read property",
    "is not a function"
];
function isConvexInternalError(message) {
    return CONVEX_INTERNAL_PREFIXES.some((prefix)=>message.startsWith(prefix));
}
function getSanitizedErrorMessage(error, fallback) {
    const raw = getErrorMessage(error, fallback);
    if (isConvexInternalError(raw)) {
        return fallback;
    }
    return raw;
}
const errorDedupeMap = new Map();
const DEDUPE_WINDOW_MS = 10_000;
const MAX_SAME_SOURCE_PER_WINDOW = 3;
function reportClientError(opts) {
    try {
        const now = Date.now();
        const sanitized = getSanitizedErrorMessage(opts.message, opts.message);
        const dedupeKey = `${opts.source}:${sanitized.slice(0, 200)}`;
        const lastSent = errorDedupeMap.get(dedupeKey);
        if (lastSent && now - lastSent < DEDUPE_WINDOW_MS) {
            return;
        }
        errorDedupeMap.set(dedupeKey, now);
        let sourceCount = 0;
        for (const [k, t] of errorDedupeMap.entries()){
            if (k.startsWith(`${opts.source}:`) && now - t < DEDUPE_WINDOW_MS) {
                sourceCount++;
            }
        }
        if (sourceCount > MAX_SAME_SOURCE_PER_WINDOW) {
            return;
        }
        fetch("/api/client-error", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                severity: opts.severity ?? "error",
                source: opts.source,
                message: opts.message,
                stackTrace: opts.stackTrace,
                metadata: opts.metadata
            }),
            keepalive: true
        }).catch(()=>{});
    } catch  {
    // Silently fail
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
function Skeleton(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "6ce6202b529e80712d474c098819ae584a1a687748d4dd8ec402e4f4a6a10561") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6ce6202b529e80712d474c098819ae584a1a687748d4dd8ec402e4f4a6a10561";
    }
    let className;
    let props;
    if ($[1] !== t0) {
        ({ className, ...props } = t0);
        $[1] = t0;
        $[2] = className;
        $[3] = props;
    } else {
        className = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== className) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("animate-pulse rounded-[8px] bg-[#f6f7fa]", className);
        $[4] = className;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== props || $[7] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t1,
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/ui/skeleton.tsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[6] = props;
        $[7] = t1;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    return t2;
}
_c = Skeleton;
;
var _c;
__turbopack_context__.k.register(_c, "Skeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/ConvexClientProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ConvexClientProvider",
    ()=>ConvexClientProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)");
;
"use client";
;
;
;
;
/**
 * Skeleton fallback shown while the Convex provider loads client-side.
 */ function AuthSkeleton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3);
    if ($[0] !== "5853c7972eb930094bfe0441039187dc9a52dddd6bb815a9e166797a3254d767") {
        for(let $i = 0; $i < 3; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5853c7972eb930094bfe0441039187dc9a52dddd6bb815a9e166797a3254d767";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
            className: "h-16 w-full"
        }, void 0, false, {
            fileName: "[project]/src/app/ConvexClientProvider.tsx",
            lineNumber: 21,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 flex flex-col",
            children: [
                t0,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 p-6 space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            className: "h-8 w-48"
                        }, void 0, false, {
                            fileName: "[project]/src/app/ConvexClientProvider.tsx",
                            lineNumber: 28,
                            columnNumber: 90
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            className: "h-64"
                        }, void 0, false, {
                            fileName: "[project]/src/app/ConvexClientProvider.tsx",
                            lineNumber: 28,
                            columnNumber: 123
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/ConvexClientProvider.tsx",
                    lineNumber: 28,
                    columnNumber: 52
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/ConvexClientProvider.tsx",
            lineNumber: 28,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    return t1;
}
_c = AuthSkeleton;
const ConvexClientProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_c1 = ()=>__turbopack_context__.A("[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthSkeleton, {}, void 0, false, {
            fileName: "[project]/src/app/ConvexClientProvider.tsx",
            lineNumber: 46,
            columnNumber: 18
        }, ("TURBOPACK compile-time value", void 0))
});
_c2 = ConvexClientProvider;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "AuthSkeleton");
__turbopack_context__.k.register(_c1, "ConvexClientProvider$dynamic");
__turbopack_context__.k.register(_c2, "ConvexClientProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GlobalErrorReporter.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GlobalErrorReporter",
    ()=>GlobalErrorReporter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const REPORTED_ERRORS = new Set();
function GlobalErrorReporter() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3);
    if ($[0] !== "0adf2b6cf6f98785e97ed7ce72874a2aeda9d837c02df8242ba7f1329fd1c6a1") {
        for(let $i = 0; $i < 3; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0adf2b6cf6f98785e97ed7ce72874a2aeda9d837c02df8242ba7f1329fd1c6a1";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(_GlobalErrorReporterUseEffect, t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}, void 0, false);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    return t1;
}
_s(GlobalErrorReporter, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = GlobalErrorReporter;
function _GlobalErrorReporterUseEffect() {
    const handleError = _GlobalErrorReporterUseEffectHandleError;
    const handleUnhandledRejection = _GlobalErrorReporterUseEffectHandleUnhandledRejection;
    window.addEventListener("error", handleError);
    window.addEventListener("unhandledrejection", handleUnhandledRejection);
    return ()=>{
        window.removeEventListener("error", handleError);
        window.removeEventListener("unhandledrejection", handleUnhandledRejection);
    };
}
function _GlobalErrorReporterUseEffectHandleUnhandledRejection(event_0) {
    const error = event_0.reason;
    const key_0 = `rejection:${error instanceof Error ? error.message : String(error).slice(0, 100)}`;
    if (REPORTED_ERRORS.has(key_0)) {
        return;
    }
    REPORTED_ERRORS.add(key_0);
    setTimeout({
        "GlobalErrorReporter[useEffect() > handleUnhandledRejection > setTimeout()]": ()=>REPORTED_ERRORS.delete(key_0)
    }["GlobalErrorReporter[useEffect() > handleUnhandledRejection > setTimeout()]"], 5000);
    const message = error instanceof Error ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(error, "Unhandled promise rejection") : typeof error === "string" ? error : "Unhandled promise rejection";
    const stack = error instanceof Error ? error.stack : undefined;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportClientError"])({
        severity: "error",
        source: "unhandledrejection",
        message,
        stackTrace: stack
    });
}
function _GlobalErrorReporterUseEffectHandleError(event) {
    const key = `${event.message}:${event.filename}:${event.lineno}`;
    if (REPORTED_ERRORS.has(key)) {
        return;
    }
    REPORTED_ERRORS.add(key);
    setTimeout({
        "GlobalErrorReporter[useEffect() > handleError > setTimeout()]": ()=>REPORTED_ERRORS.delete(key)
    }["GlobalErrorReporter[useEffect() > handleError > setTimeout()]"], 5000);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportClientError"])({
        severity: "error",
        source: "window.onerror",
        message: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(event.error, event.message || "Unhandled error"),
        stackTrace: event.error?.stack,
        metadata: {
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno
        }
    });
}
var _c;
__turbopack_context__.k.register(_c, "GlobalErrorReporter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_66050937._.js.map