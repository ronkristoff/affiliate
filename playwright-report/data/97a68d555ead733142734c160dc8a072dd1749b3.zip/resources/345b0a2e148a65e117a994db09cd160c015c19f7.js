(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_73f4d2f6._.js",
  "static/chunks/0f0ec_next_dist_compiled_react-dom_00222e6f._.js",
  "static/chunks/0f0ec_next_dist_compiled_react-server-dom-turbopack_b713821e._.js",
  "static/chunks/0f0ec_next_dist_compiled_next-devtools_index_60c39296.js",
  "static/chunks/0f0ec_next_dist_compiled_d9b1eec3._.js",
  "static/chunks/0f0ec_next_dist_client_2a053e52._.js",
  "static/chunks/0f0ec_next_dist_c1a0b2a7._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
