(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_33024ba5._.js",
  "static/chunks/src_d86f7f8c._.js",
  "static/chunks/src_app_ConvexInnerProvider_tsx_f673c4df._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);