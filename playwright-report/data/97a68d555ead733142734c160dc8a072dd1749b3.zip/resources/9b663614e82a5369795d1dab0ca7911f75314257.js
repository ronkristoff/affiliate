(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__23141740._.css",
  "static/chunks/src_app_ConvexInnerProvider_tsx_69a1c8bf._.js",
  "static/chunks/node_modules__pnpm_e55472df._.js",
  "static/chunks/src_66050937._.js"
],
    source: "dynamic"
});
