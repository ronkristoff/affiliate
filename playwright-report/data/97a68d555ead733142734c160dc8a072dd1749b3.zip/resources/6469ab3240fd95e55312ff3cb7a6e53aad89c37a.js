(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4d26ac40._.js",
  "static/chunks/1ce87_react-hook-form_dist_index_esm_mjs_53643110._.js",
  "static/chunks/6cc6f_better-auth_dist_648e535c._.js",
  "static/chunks/0f0ec_next_b82df26c._.js",
  "static/chunks/f43be_convex_dist_esm_15665b8c._.js",
  "static/chunks/a8d7e_zod_v4_be3268ef._.js",
  "static/chunks/node_modules__pnpm_d0037b1e._.js"
],
    source: "dynamic"
});
