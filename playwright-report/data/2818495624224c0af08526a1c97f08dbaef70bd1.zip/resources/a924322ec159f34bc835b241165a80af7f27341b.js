(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/auth-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authClient",
    ()=>authClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/client/plugins/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$two$2d$factor$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/plugins/two-factor/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$magic$2d$link$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/plugins/magic-link/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$email$2d$otp$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/plugins/email-otp/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$generic$2d$oauth$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/plugins/generic-oauth/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$anonymous$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/plugins/anonymous/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$additional$2d$fields$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/plugins/additional-fields/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/better-auth@1.5.3_next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-r_cafaecaf4e7995fa53629656de426d87/node_modules/better-auth/dist/client/react/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$convex$2d$dev$2b$better$2d$auth$40$0$2e$11$2e$4_$40$standard$2d$schema$2b$spec$40$1$2e$1$2e$0_better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$_dd98353b55d17b3cc411fd2d34e67691$2f$node_modules$2f40$convex$2d$dev$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@convex-dev+better-auth@0.11.4_@standard-schema+spec@1.1.0_better-auth@1.5.3_next@16.1._dd98353b55d17b3cc411fd2d34e67691/node_modules/@convex-dev/better-auth/dist/client/plugins/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$convex$2d$dev$2b$better$2d$auth$40$0$2e$11$2e$4_$40$standard$2d$schema$2b$spec$40$1$2e$1$2e$0_better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$_dd98353b55d17b3cc411fd2d34e67691$2f$node_modules$2f40$convex$2d$dev$2f$better$2d$auth$2f$dist$2f$plugins$2f$convex$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@convex-dev+better-auth@0.11.4_@standard-schema+spec@1.1.0_better-auth@1.5.3_next@16.1._dd98353b55d17b3cc411fd2d34e67691/node_modules/@convex-dev/better-auth/dist/plugins/convex/client.js [app-client] (ecmascript)");
;
;
;
// Keep twoFactorClient import available for conditional use above
void __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$two$2d$factor$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twoFactorClient"];
const authClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAuthClient"])({
    plugins: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$additional$2d$fields$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inferAdditionalFields"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$anonymous$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["anonymousClient"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$magic$2d$link$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["magicLinkClient"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$email$2d$otp$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emailOTPClient"])(),
        // Only include twoFactor client plugin when enabled
        ...("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : [],
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$r_cafaecaf4e7995fa53629656de426d87$2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$generic$2d$oauth$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["genericOAuthClient"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$convex$2d$dev$2b$better$2d$auth$40$0$2e$11$2e$4_$40$standard$2d$schema$2b$spec$40$1$2e$1$2e$0_better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$_dd98353b55d17b3cc411fd2d34e67691$2f$node_modules$2f40$convex$2d$dev$2f$better$2d$auth$2f$dist$2f$plugins$2f$convex$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convexClient"])()
    ]
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConvexInnerProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.0_@babel+core@7.29.0_@playwright+test@1.59.1_babel-plugin-react-compiler@1.0._ceab129847dc8b0ade5725a042a88946/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$convex$40$1$2e$35$2e$1_react$40$19$2e$2$2e$3$2f$node_modules$2f$convex$2f$dist$2f$esm$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/convex@1.35.1_react@19.2.3/node_modules/convex/dist/esm/react/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$convex$40$1$2e$35$2e$1_react$40$19$2e$2$2e$3$2f$node_modules$2f$convex$2f$dist$2f$esm$2f$react$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/convex@1.35.1_react@19.2.3/node_modules/convex/dist/esm/react/client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$convex$2d$dev$2b$better$2d$auth$40$0$2e$11$2e$4_$40$standard$2d$schema$2b$spec$40$1$2e$1$2e$0_better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$_dd98353b55d17b3cc411fd2d34e67691$2f$node_modules$2f40$convex$2d$dev$2f$better$2d$auth$2f$dist$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@convex-dev+better-auth@0.11.4_@standard-schema+spec@1.1.0_better-auth@1.5.3_next@16.1._dd98353b55d17b3cc411fd2d34e67691/node_modules/@convex-dev/better-auth/dist/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const convex = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$convex$40$1$2e$35$2e$1_react$40$19$2e$2$2e$3$2f$node_modules$2f$convex$2f$dist$2f$esm$2f$react$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvexReactClient"](("TURBOPACK compile-time value", "http://127.0.0.1:3210"), {
    verbose: false
});
/**
 * Clear stale 2FA cookies when 2FA is disabled.
 *
 * When TWO_FACTOR_ENABLED was previously true, Better Auth sets a
 * __Secure-better-auth.two_factor cookie. Even after disabling the
 * twoFactor plugin, this cookie persists and causes ConvexBetterAuthProvider
 * to redirect to /verify-2fa on session restore.
 */ function clearStale2FACookies() {
    const cookiesToClear = [
        "__Secure-better-auth.two_factor",
        "better-auth.two_factor"
    ];
    for (const name of cookiesToClear){
        document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax`;
    }
}
function ConvexInnerProvider(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "890536aab98a81c16bbaefc19fb834e3bc3aac5bc26cf938b7c62917f6c2cfeb") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "890536aab98a81c16bbaefc19fb834e3bc3aac5bc26cf938b7c62917f6c2cfeb";
    }
    const { children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(_ConvexInnerProviderUseEffect, t1);
    let t2;
    if ($[2] !== children) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$0_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_babel$2d$plugin$2d$react$2d$compiler$40$1$2e$0$2e$_ceab129847dc8b0ade5725a042a88946$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$convex$2d$dev$2b$better$2d$auth$40$0$2e$11$2e$4_$40$standard$2d$schema$2b$spec$40$1$2e$1$2e$0_better$2d$auth$40$1$2e$5$2e$3_next$40$16$2e$1$2e$_dd98353b55d17b3cc411fd2d34e67691$2f$node_modules$2f40$convex$2d$dev$2f$better$2d$auth$2f$dist$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvexBetterAuthProvider"], {
            client: convex,
            authClient: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"],
            children: children
        }, void 0, false, {
            fileName: "[project]/src/app/ConvexInnerProvider.tsx",
            lineNumber: 54,
            columnNumber: 10
        }, this);
        $[2] = children;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_s(ConvexInnerProvider, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ConvexInnerProvider;
function _ConvexInnerProviderUseEffect() {
    if ("TURBOPACK compile-time truthy", 1) {
        clearStale2FACookies();
    }
}
var _c;
__turbopack_context__.k.register(_c, "ConvexInnerProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/ConvexInnerProvider.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=src_d86f7f8c._.js.map