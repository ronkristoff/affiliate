(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_33024ba5._.js",
  "static/chunks/src_d86f7f8c._.js"
],
    source: "dynamic"
});
